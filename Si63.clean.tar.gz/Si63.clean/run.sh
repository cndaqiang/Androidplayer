. /opt/intel/oneapi/compiler/2022.2.0/env/vars.sh
. /opt/intel/oneapi/mkl/2022.2.0/env/vars.sh
MPIPATH=/opt/mpich
PATH=$MPIPATH/bin:$PATH
#LD_LIBRARY_PATH=$MPIPATHlib:$LD_LIBRARY_PATH
#LIBRARY_PATH=$MPIPATHlib:$LIBRARY_PATH
#C_INCLUDE_PATH=$MPIPATHinclude:$C_INCLUDE_PATH
EXEC=/opt/vasp/vasp_std
mpirun -np 4 $EXEC | tee result



