#!/bin/bash
##################################
# Author : cndaqiang             #
# Update : 2019-04-11            #
# Build  : 2019-04-11            #
# What   : 清除VASP计算结果      #
##################################
#清除计算结果
rm CHG* CONTCAR* DOSCAR* DYNMAT EIGENVAL IBZKPT OPTIC OSZICAR* OUTCAR* \
   PCDAT W* XDATCAR*  vasprun.xml   PROCAR  REPORT

